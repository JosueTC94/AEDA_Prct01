#pragma once
typedef int TDATO;

using namespace std;
